// Puedes agregar aquí funcionalidades JS extra si lo necesitas.
// Por ejemplo, para animaciones, menú móvil, etc.
